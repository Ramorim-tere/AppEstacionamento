package br.edu.unifeso.controleestacionamento.Activity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import br.edu.unifeso.controleestacionamento.R;

public class CadVeiculo extends AppCompatActivity {
    public String vVeiculo;

    EditText nome, marca, placa, VagaUtilizada, Area,  tipo, HoraEntrada, HoraSaida ;
    Button limpar, salvar, editar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_veiculo);

        editar = (Button) findViewById(R.id.btnEditar);
        limpar = (Button) findViewById(R.id.btnLimpar);
        salvar = (Button) findViewById(R.id.btnSalvar);


        nome =  (EditText) findViewById(R.id.editNome);
        marca = (EditText) findViewById(R.id.editMarca);
        placa = (EditText) findViewById(R.id.editPlaca);
        tipo = (EditText) findViewById(R.id.editTipo);
        VagaUtilizada = (EditText) findViewById(R.id.editVagaNum);
        Area = (EditText) findViewById(R.id.editArea);
        HoraEntrada = (EditText) findViewById(R.id.editHrEntrada);
        HoraSaida = (EditText) findViewById(R.id.editHrSaida);
    }

    public void limpar(View view) {
        nome.setText("");
        marca.setText("");
        placa.setText("");
        tipo.setText("");
        VagaUtilizada.setText("");
        Area.setText("");
        HoraEntrada.setText("");
        HoraSaida.setText("");
    }

    public void salvar(View view) {
        SharedPreferences prefs = getSharedPreferences("preferencias", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        ed.putString("nome", nome.getText().toString());
        ed.putString("marca", marca.getText().toString());
        ed.putString("placa", placa.getText().toString());
        ed.putString("tipo", tipo.getText().toString());
        ed.putString("VagaUtilizada", VagaUtilizada.getText().toString());
        ed.putString("Area", Area.getText().toString());
        ed.putString("horaentrada", HoraEntrada.getText().toString());
        ed.putString("horasaida", HoraSaida.getText().toString());

        ed.apply();
        Toast.makeText(getBaseContext(), "Gravado com sucesso", Toast.LENGTH_SHORT).show();


    }
}

