package br.edu.unifeso.controleestacionamento.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import br.edu.unifeso.controleestacionamento.R;

public class ConsVeic extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cons_veic);
    }
}
