package br.edu.unifeso.controleestacionamento.Activity;

import android.content.Context;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.function.BiFunction;

import br.edu.unifeso.controleestacionamento.R;

public class CadVaga extends AppCompatActivity {
    public String vVaga;

    EditText Area, NumVaga;
    Button limpar, salvar, editar;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cad_vaga);

        editar = (Button) findViewById(R.id.btnCadVagaEditar);
        limpar = (Button) findViewById(R.id.btnCadVagaLimpar);
        salvar = (Button) findViewById(R.id.btnCadVagaSalvar);


        Area = (EditText) findViewById(R.id.editArea);
        NumVaga = (EditText) findViewById(R.id.editNumVaga);

    }

    public void limpar(View view) {
        Area.setText("");
        NumVaga.setText("");

    }

    public void salvar(View view) {
        SharedPreferences prefs = getSharedPreferences("preferencias", Context.MODE_PRIVATE);
        SharedPreferences.Editor ed = prefs.edit();
        ed.putString("area", Area.getText().toString());
        ed.putString("numVaga", NumVaga.getText().toString());


        ed.apply();
        Toast.makeText(getBaseContext(), "Gravado com sucesso", Toast.LENGTH_SHORT).show();

    }

}
