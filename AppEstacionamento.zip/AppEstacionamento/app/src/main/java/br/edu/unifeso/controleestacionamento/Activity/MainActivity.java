package br.edu.unifeso.controleestacionamento.Activity;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import br.edu.unifeso.controleestacionamento.R;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button BtnCadVeic = findViewById(R.id.BtnCadVeic);
        BtnCadVeic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CadVeiculo.class);
                startActivity(intent);

            }
        });

        Button BtnCadVaga = findViewById(R.id.BtnCadVaga);
        BtnCadVaga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CadVaga.class);
                startActivity(intent);

            }
        });

        Button BtnConsVeic = findViewById(R.id.BtnConsVeic);
        BtnConsVeic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ConsVeic.class);
                startActivity(intent);

            }
        });

        Button BtnListVaga = findViewById(R.id.BtnListVaga);
        BtnListVaga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListVaga.class);
                startActivity(intent);

            }
        });

        Button BtnListVeic = findViewById(R.id.BtnListVeic);
        BtnListVeic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListVeic.class);
                startActivity(intent);

            }
        });

        Button button = (Button) findViewById(R.id.BtnSairApp);
            button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    finish();
                }
            });
    }


}
